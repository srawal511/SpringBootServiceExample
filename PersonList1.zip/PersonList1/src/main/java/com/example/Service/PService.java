package com.example.Service;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.stream.Stream;
import org.springframework.stereotype.Service;

import com.example.model.*;

@Service
public class PService {
	ArrayList<Person> persons = new ArrayList<Person>();
	public PService() {
		Person p = new Person();
		p.setId("1");
		
		p.setFirstName("Steve");
		p.setLastName("Smith");
		persons.add(p);

		p = new Person();
		p.setId("2");
	
		p.setFirstName("Tom");
		p.setLastName("Brown");
		persons.add(p);
	}
	
	public ArrayList<Person> getAll() {
		return persons;
	}
}