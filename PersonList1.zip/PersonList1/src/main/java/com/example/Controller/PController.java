package com.example.Controller;


import java.util.ArrayList;
import java.util.Hashtable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.*;
import com.example.Service.*;


@CrossOrigin
@RestController
@RequestMapping("/persons")
public class PController {

	@Autowired
	PService ps;

	@RequestMapping("/all")
	public ArrayList<Person> getAll() {
		return ps.getAll();
	}

}
